import React, { useState, useEffect } from 'react';
import ManagementTable from '../Components/display/Table';
import Chip from '@mui/joy/Chip';
import IconButton from '@mui/joy/IconButton';
import VisibilityIcon from '@mui/icons-material/Visibility';
import CustomNavBar from '../Components/display/TablePagination'; 
import AddPositionDrawer from '../Components/drw/AddPositionDrawer'; 
import TableActionBar from '../Components/display/TableActionBar';

import managementApi from "../api/managementapi.js"

const TrangThaiDisplay = ({ trangThai }) => (
    <Chip variant="soft" color={trangThai ? "success" : "danger"}>{trangThai ? "Đang hoạt động" : "Ngừng hoạt động"}</Chip>
);

const HanhDongDisplay = ({ hanhDong }) => (
    <IconButton size="sm" variant="outlined" color="neutral" style={{ padding: '0.25rem', gap: '0.5rem' }}>
        <VisibilityIcon /> {hanhDong}
    </IconButton>
);

function convertToRenderableData(input) {
    return {
        ma: input.code || "N/A",
        ten: input.name || "N/A",
        moTa: input.des || "N/A",
        trangThai: input.isActive,
        hanhDong: "Chi tiết"
    };
}

function PositionDetail() {
    const head = ["Mã", "Tên", "Mô tả", "Trạng thái", "Hành động"];
    const [data, setData] = useState([]);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [currentPage, setCurrentPage] = useState(1); 
    const [recordsPerPage, setRecordsPerPage] = useState(10); 
    const [totalRecords, setTotalRecords] = useState(0); 
    const recordsPerPageOptions = [10, 20, 50]; 

    const handleAddPosition = async (positionData) => {
        try {
            await managementApi.createTeacherPosition(positionData);
            console.log('Position data saved successfully:', positionData);
            setIsDrawerOpen(false);
            loadTable(); 
        } catch (error) {
            console.error('Error saving position data:', error);
        }
    };

    const truthTable = {
        "Mã": "ma",
        "Tên": "ten",
        "Mô tả": "moTa",
        "Trạng thái": "trangThai",
        "Hành động": "hanhDong"
    };

    const customDataDisplay = {
        "Trạng thái": (trangThai) => <TrangThaiDisplay trangThai={trangThai} />,
        "Hành động": (hanhDong) => <HanhDongDisplay hanhDong={hanhDong} />,
    };

    const loadTable = async () => {
        setData([])
        try {
            const _data = await managementApi.getTeacherPositions();
            console.log(_data);
            let newData = [];
            _data.data.forEach((e) => {
                newData.push(convertToRenderableData(e));
            });
            setData(newData);
            setTotalRecords(_data.length); 
        } catch (error) {
            console.error("Error loading teacher positions:", error);
        }
    }

    useEffect(() => {
        loadTable()
    }, [])

    const handlePageChange = (page) => {
        setCurrentPage(page);
        console.log('Page changed to:', page);
    };

    const handleSetRecordsPerPage = (newRecordsPerPage) => {
        setRecordsPerPage(newRecordsPerPage);
        setCurrentPage(1);
        console.log('Records per page changed to:', newRecordsPerPage);
    };

    return (
        <div>
            <div>
                <h1>Teacher Positions Management</h1>

                <TableActionBar
                    SearchChange={(e) => { console.log("Search:", e) }}
                    ReloadCallback={() => { loadTable() }}
                    AddNewCallback={() => setIsDrawerOpen(true)}
                />
                <ManagementTable
                    head={head}
                    data={data}
                    truthTable={truthTable}
                    customDataDisplay={customDataDisplay}
                />
                {totalRecords > recordsPerPage && ( 
                    <CustomNavBar
                        totalRecords={totalRecords}
                        currentPage={currentPage}
                        recordsPerPage={recordsPerPage}
                        recordsPerPageOptions={recordsPerPageOptions}
                        setRecordPerPage={handleSetRecordsPerPage}
                        changePage={handlePageChange}
                    />
                )}
                <AddPositionDrawer
                    open={isDrawerOpen}
                    onClose={() => setIsDrawerOpen(false)}
                    addPositionCallback={handleAddPosition}e
                />
            </div>
            <hr />
        </div>
    )
}

export default PositionDetail;