import React, { useState, useEffect } from 'react';
import ManagementTable from '../Components/display/Table';
import Avatar from '@mui/joy/Avatar';
import Chip from '@mui/joy/Chip';
import IconButton from '@mui/joy/IconButton';
import VisibilityIcon from '@mui/icons-material/Visibility';
import CustomNavBar from '../Components/display/TablePagination';
import AddTeacherDrawer from '../Components/drw/AddTeacherDrawer';
import TableActionBar from '../Components/display/TableActionBar';

import managementApi from "../api/managementapi.js"

const GiaoVienDisplay = ({ giaoVien }) => (
    <div style={{ width: '100%', display: 'flex', alignItems: 'center' }}>
        <Avatar src={giaoVien.avatar ? giaoVien.avatar : ""} style={{ marginRight: 8, height: "100%", aspectRatio: "1/1" }} >
            {giaoVien.avatar ? "" : "GV"}
        </Avatar>
        <div>
            <div>{giaoVien.name}</div>
            <div style={{ fontSize: '0.8rem', color: 'grey' }}>{giaoVien.email}</div>
            <div style={{ fontSize: '0.8rem', color: 'grey' }}>{giaoVien.phone}</div>
        </div>
    </div>
);

const TrinhDoDisplay = ({ trinhDo }) => (
    <div>
        <div>Bậc: {trinhDo.bac}</div>
        <div>Chuyên ngành: {trinhDo.chuyenNganh}</div>
    </div>
);

const TrangThaiDisplay = ({ trangThai }) => (
    <Chip variant="soft" color="success">{trangThai}</Chip>
);

const HanhDongDisplay = ({ hanhDong }) => (
    <IconButton size="sm" variant="outlined" color="neutral" style={{ padding: '0.25rem', gap: '0.5rem' }}>
        <VisibilityIcon /> {hanhDong}
    </IconButton>
);

function convertToRenderableData(input) {
    return {
        ma: input.code || "N/A",
        giaoVien: {
            name: input.user?.name || "N/A",
            email: input.user?.email || "N/A",
            phone: input.user?.phoneNumber || "N/A",
            avatar: "GV"
        },
        trinhDo: {
            bac: input.degrees?.[0]?.type === "Master" ? "Thạc sĩ" : input.degrees?.[0]?.type || "N/A",
            chuyenNganh: input.degrees?.[0]?.major || "N/A"
        },
        boMon: input.teacherPositions?.[0]?.name || "N/A",
        ttCongTac: input.isActive ? "Đang công tác" : "Không công tác",
        diaChi: input.user?.address || "N/A",
        trangThai: input.isActive ? "Đang công tác" : "Không công tác",
        hanhDong: "Chi tiết"
    };
}

function Dashboard() {
    const head = ["Mã", "Giáo viên", "Trình độ (cao nhất)", "Bộ môn", "TT Công tác", "Địa chỉ", "Trạng thái", "Hành động"];
    const [data, setData] = useState([]);
    const [positionsData, setPositionsData] = useState([
        { id: 'GiaoVien', name: 'Giáo viên' },
        { id: 'HieuTruong', name: 'Hiệu trưởng' },
        { id: 'PhoHieuTruong', name: 'Phó hiệu trưởng' },
    ])
    const [currentPage, setCurrentPage] = useState(1);
    const [recordsPerPage, setRecordsPerPage] = useState(10);
    const [totalRecords, setTotalRecords] = useState(10);
    const recordsPerPageOptions = [10, 20, 50];
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const handleAddTeacher = (teacherData) => {
        console.log('Teacher data to be saved:', teacherData);
    };
    const truthTable = {
        "Mã": "ma",
        "Giáo viên": "giaoVien",
        "Trình độ (cao nhất)": "trinhDo",
        "Bộ môn": "boMon",
        "TT Công tác": "ttCongTac",
        "Địa chỉ": "diaChi",
        "Trạng thái": "trangThai",
        "Hành động": "hanhDong"
    };

    const customDataDisplay = {
        "Giáo viên": (giaoVien) => <GiaoVienDisplay giaoVien={giaoVien} />,
        "Trình độ (cao nhất)": (trinhDo) => <TrinhDoDisplay trinhDo={trinhDo} />,
        "Trạng thái": (trangThai) => <TrangThaiDisplay trangThai={trangThai} />,
        "Hành động": (hanhDong) => <HanhDongDisplay hanhDong={hanhDong} />,
    };

    const customColSize = {
        "Giáo viên": "20%",
        "Trình độ (cao nhất)": "20%",
    };
    const loadTable = async () => {
        setData([])
        let _data = await managementApi.getTeachers(currentPage, recordsPerPage);
        console.log(_data)
        let newData = []
        _data.data.forEach((e) => {
            newData.push(convertToRenderableData(e))
        })
        setData(newData)
        setTotalRecords(_data.pagination.totalItems)
    }
    useEffect(() => {
        loadTable()
    }, [currentPage, recordsPerPage])

    const handlePageChange = (page) => {
        setCurrentPage(page);
        console.log('Page changed to:', page);
    };

    const handleSetRecordsPerPage = (newRecordsPerPage) => {
        setRecordsPerPage(newRecordsPerPage);
        setCurrentPage(1);
        console.log('Records per page changed to:', newRecordsPerPage);
    };

    return (
        <div>

            <div>
                <h1>Management Table</h1>

                <TableActionBar
                    SearchChange={(e) => { console.log("Search:", e) }}
                    ReloadCallback={() => { loadTable() }}
                    AddNewCallback={() => setIsDrawerOpen(true)}
                />
                <ManagementTable
                    head={head}
                    data={data}
                    truthTable={truthTable}
                    customDataDisplay={customDataDisplay}
                    customColSize={customColSize}
                />
                <CustomNavBar
                    totalRecords={totalRecords}
                    currentPage={currentPage}
                    recordsPerPage={recordsPerPage}
                    recordsPerPageOptions={recordsPerPageOptions}
                    setRecordPerPage={handleSetRecordsPerPage}
                    changePage={handlePageChange}

                />
                <AddTeacherDrawer
                    positions={positionsData}
                    open={isDrawerOpen}
                    onClose={() => setIsDrawerOpen(false)}
                    addTeacherCallback={handleAddTeacher}
                />
            </div>
        </div>
    )
}

export default Dashboard