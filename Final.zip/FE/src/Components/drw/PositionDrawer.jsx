import React, { useState } from 'react';
import {
    Drawer,
    Box,
    IconButton,
    Typography,
    TextField,
    Grid,
    Button,
    Alert,
    FormControlLabel,
    Switch,
} from '@mui/material';
import { Close as CloseIcon } from '@mui/icons-material';

const AddPositionDrawer = ({ open, onClose, addPositionCallback }) => {
    const [positionInfo, setPositionInfo] = useState({
        code: '',
        name: '',
        des: '',
        isActive: true,
    });
    const [apiError, setApiError] = useState(null);
    const [apiSuccess, setApiSuccess] = useState(null);

    const handleInputChange = (e) => {
        setPositionInfo({ ...positionInfo, [e.target.name]: e.target.value });
    };

    const handleActiveChange = (event) => {
        setPositionInfo({ ...positionInfo, isActive: event.target.checked });
    };

    const handleSave = async () => {
        setApiError(null);
        setApiSuccess(null);

        try {
            if (!positionInfo.code || !positionInfo.name) {
                setApiError("Mã vị trí và Tên vị trí là bắt buộc.");
                return;
            }
            await addPositionCallback(positionInfo);
            setApiSuccess("Vị trí đã được tạo thành công.");
            setTimeout(() => {
                onClose();
                setPositionInfo({
                    code: '',
                    name: '',
                    des: '',
                    isActive: true,
                });
                setApiSuccess(null);
            }, 1500);
        } catch (error) {
            console.error("Error creating position:", error);
            setApiError(error.message || "Error creating position.");
        }
    };


    return (
        <Drawer
            anchor="right"
            open={open}
            onClose={onClose}
            PaperProps={{ sx: { width: '50vw' } }}
        >
            <Box sx={{ p: 3 }}>
                <IconButton onClick={onClose} sx={{ position: 'absolute', top: 8, right: 8 }}>
                    <CloseIcon />
                </IconButton>
                <Typography variant="h6" mb={2}>
                    Thêm mới vị trí công tác
                </Typography>

                {apiError && (
                    <Alert severity="error" sx={{ mb: 2 }}>{apiError}</Alert>
                )}
                {apiSuccess && (
                    <Alert severity="success" sx={{ mb: 2 }}>{apiSuccess}</Alert>
                )}

                <Grid container spacing={2}>
                    <Grid item xs={12}>
                        <TextField
                            fullWidth
                            label="Mã vị trí"
                            name="code"
                            variant="outlined"
                            size="small"
                            margin="dense"
                            required
                            placeholder="VD: GVBM"
                            value={positionInfo.code}
                            onChange={handleInputChange}
                        />
                    </Grid>

                    <Grid item xs={12}>
                        <TextField
                            fullWidth
                            label="Tên vị trí"
                            name="name"
                            variant="outlined"
                            size="small"
                            margin="dense"
                            required
                            placeholder="VD: Giáo viên bộ môn"
                            value={positionInfo.name}
                            onChange={handleInputChange}
                        />
                    </Grid>

                    <Grid item xs={12}>
                        <TextField
                            fullWidth
                            label="Mô tả"
                            name="des"
                            variant="outlined"
                            size="small"
                            margin="dense"
                            placeholder="Mô tả vị trí (không bắt buộc)"
                            value={positionInfo.des}
                            onChange={handleInputChange}
                            multiline
                            rows={3}
                        />
                    </Grid>

                    <Grid item xs={12}>
                        <FormControlLabel
                            control={
                                <Switch
                                    checked={positionInfo.isActive}
                                    onChange={handleActiveChange}
                                    name="isActive"
                                    color="primary"
                                />
                            }
                            label="Trạng thái hoạt động"
                        />
                    </Grid>


                </Grid>


                <Box mt={3} display="flex" justifyContent="flex-end">
                    <Button variant="contained" color="primary" onClick={handleSave}>
                        Lưu
                    </Button>
                </Box>
            </Box>
        </Drawer>
    );
};

export default AddPositionDrawer;