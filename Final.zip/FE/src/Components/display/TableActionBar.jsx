import React from 'react'

import { Box } from "@mui/material"
import Input from "@mui/joy/Input"
import SearchIcon from '@mui/icons-material/Search';
import Button from '@mui/joy/Button';
import IconButton from '@mui/joy/IconButton';
import CachedIcon from '@mui/icons-material/Cached';
import PersonAddIcon from '@mui/icons-material/PersonAdd';

function TableActionBar({ SearchChange = (e) => { }, ReloadCallback = () => { }, AddNewCallback = () => { } }) {
    return (
        <Box display="flex" alignItems="center" justifyContent="right" width="100%" gap="5px">
            <Input
                placeholder="Tìm kiếm thông tin"
                variant='outlined'
                size="sm"
                startDecorator={<IconButton variant='plain'><SearchIcon /></IconButton>}
                onChange={(e) => { e.preventDefault(); SearchChange(e.target.value) }}
            />
            <Button size="sm" startDecorator={<CachedIcon />}
                variant='outlined'
                onClick={() => ReloadCallback()}
            >Tải lại</Button>
            <Button size="sm" startDecorator={<PersonAddIcon />}
                variant='outlined'
                onClick={() => AddNewCallback()}
            >Tạo mới</Button>
        </Box>
    )
}

export default TableActionBar