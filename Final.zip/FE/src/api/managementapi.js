import axios from 'axios';

const API_BASE_URL = 'http://localhost:3000/api';

const managementApi = {
  getTeacherPositions: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/teacher-positions`);
      return response.data;
    } catch (error) {
      console.error("Error fetching teacher positions:", error);
      throw error; 
    }
  },

  createTeacherPosition: async (teacherPositionData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/teacher-positions`, teacherPositionData);
      return response.data;
    } catch (error) {
      console.error("Error creating teacher position:", error);
      throw error;
    }
  },

  getTeachers: async (page = 1, limit = 10) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/teachers`, {
        params: {
          page,
          limit,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching teachers:", error);
      throw error;
    }
  },

  createTeacher: async (teacherData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/teachers`, teacherData);
      return response.data;
    } catch (error) {
      console.error("Error creating teacher:", error);
      throw error;
    }
  },
};

export default managementApi;