import express from 'express';
import teacherController from '../controllers/teacher.controller.js';

const router = express.Router();

router.get('/teachers', teacherController.getTeachers);
router.post('/teachers', teacherController.createTeacher);

export default router;