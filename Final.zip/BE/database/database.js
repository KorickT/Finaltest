import mongoose, { connect } from "mongoose";

const db = {
    connect: async () => {
        const DB_URL = "mongodb+srv://versysresearch:vrxUmgusi1231_saW4u%40@cluster0.8epl4.mongodb.net/mindx_test?retryWrites=true&w=majority&appName=Cluster0"
        await mongoose.connect(DB_URL)
        console.log('Connected to database')
    }
}

export default db