import mongoose from 'mongoose';

const teacherPositionSchema = new mongoose.Schema({
  name: {
    type: String,
  },
  code: {
    type: String,
    unique: true,
  },
  des: {
    type: String,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  isDeleted: {
    type: Boolean,
    default: false,
  },
}, {
  timestamps: true,
  collection: 'TeacherPositions', 
});

const TeacherPosition = mongoose.model('TeacherPosition', teacherPositionSchema);

export default TeacherPosition;