import Teacher from '../models/teacher.model.js';
import User from '../models/user.model.js';

const getAllTeachers = async (page = 1, limit = 10) => {
    const skip = (page - 1) * limit;
    const teachers = await Teacher.find({ isDeleted: false })
        .populate({
            path: 'userId',
            match: { role: { $ne: 'ADMIN' } },
            select: 'name email phoneNumber address',
        })
        .populate({
            path: 'teacherPositionsId',
            select: 'name code',
        })
        .skip(skip)
        .limit(limit)
        .sort({ createdAt: -1 })
        .lean();

    const totalTeachers = await Teacher.countDocuments({ isDeleted: false });
    const totalPages = Math.ceil(totalTeachers / limit);
    return {
        teachers,
        pagination: {
            currentPage: page,
            totalPages: totalPages,
            totalItems: totalTeachers,
            limit: limit,
        },
    };
};


const createTeacher = async (teacherData) => {
    return await Teacher.create(teacherData);
};

const getTeacherByCode = async (code) => {
    return await Teacher.findOne({ code });
};


const getTeacherByEmail = async (email) => {
    const user = await User.findOne({ email: email });
    if (!user) {
        return null;
    }
    return await Teacher.findOne({ userId: user._id });
};


export default {
    getAllTeachers,
    createTeacher,
    getTeacherByCode,
    getTeacherByEmail,
};