import TeacherPosition from '../models/teacherPosition.model.js';

const getAllTeacherPositions = async () => {
    return await TeacherPosition.find({ isDeleted: false }).sort({ createdAt: -1 });
};

const createTeacherPosition = async (teacherPositionData) => {
    return await TeacherPosition.create(teacherPositionData);
};

const getTeacherPositionByCode = async (code) => {
    return await TeacherPosition.findOne({ code });
};


export default {
    getAllTeacherPositions,
    createTeacherPosition,
    getTeacherPositionByCode,
};