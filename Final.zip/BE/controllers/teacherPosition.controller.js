import teacherPositionRepository from '../repositories/teacherPosition.repository.js';

const getTeacherPositions = async (req, res) => {
  try {
    const teacherPositions = await teacherPositionRepository.getAllTeacherPositions();
    res.status(200).json({
      success: true,
      data: teacherPositions,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

const createTeacherPosition = async (req, res) => {
  try {
    const { name, code, des } = req.body;

    const existingPosition = await teacherPositionRepository.getTeacherPositionByCode(code);
    if (existingPosition) {
      return res.status(400).json({
        success: false,
        message: 'Mã vị trí công tác đã tồn tại.',
      });
    }

    res.status(201).json({
      success: true,
      data: newTeacherPosition,
      message: 'Tạo vị trí công tác thành công!',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export default {
  getTeacherPositions,
  createTeacherPosition,
};