import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: {
    type: String,
  },
  email: {
    type: String,
    unique: true, 
    lowercase: true, 
    trim: true,
  },
  phoneNumber: {
    type: String,
  },
  address: {
    type: String,
  },
  identity: {
    type: String,
  },
  dob: {
    type: Date,
  },
  isDeleted: {
    type: Boolean,
    default: false,
  },
  role: {
    type: String,
    enum: ['STUDENT', 'TEACHER', 'ADMIN'],
    default: 'STUDENT',
  },
  accountId: {
    type: mongoose.Schema.Types.ObjectId, 
  },
}, {
  timestamps: true,
  collection: 'Users',
});

const User = mongoose.model('User', userSchema);

export default User;