import User from '../models/user.model.js';

const getUserById = async (id) => {
    return await User.findById(id);
};

const getUserByEmail = async (email) => {
    return await User.findOne({ email });
};

const createUser = async (userData) => {
    try {
        const newUser = await User.create(userData);
        return newUser;
    } catch (error) {
        console.error("Error creating user:", error);
        
    }
};


export default {
    getUserById,
    getUserByEmail,
    createUser,
};