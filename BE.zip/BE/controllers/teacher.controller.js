import teacherRepository from '../repositories/teacher.repository.js';
import userRepository from '../repositories/user.repository.js';
import generateRandomCode from '../utils/randomCode.util.js';
import { isValidObjectId } from 'mongoose';

const getTeachers = async (req, res) => {
    try {
        let page = parseInt(req.query.page);
        let limit = parseInt(req.query.limit);

        if (req.query.page !== undefined && (isNaN(page) || page <= 0)) {
            return res.status(400).json({
                success: false,
                message: 'Tham số không hợp lệ',
            });
        }

        if (req.query.limit !== undefined && (isNaN(limit) || limit <= 0)) {
            return res.status(400).json({
                success: false,
                message: 'Tham số không hợp lệ',
            });
        }

        page = page || 1;
        limit = limit || 10;

        const { teachers, pagination } = await teacherRepository.getAllTeachers(page, limit);

        const formattedTeachers = teachers.map((teacher) => {
            try {
                const user = teacher.userId;
                const positions = teacher.teacherPositionsId;

                if (user) {
                    return {
                        _id: teacher._id,
                        code: teacher.code,
                        isActive: teacher.isActive,
                        startDate: teacher.startDate,
                        endDate: teacher.endDate,
                        degrees: teacher.degrees,
                        createdAt: teacher.createdAt,
                        updatedAt: teacher.updatedAt,
                        user: {
                            _id: user._id,
                            name: user.name,
                            email: user.email,
                            phoneNumber: user.phoneNumber,
                            address: user.address,
                        },
                        teacherPositions: positions.map((pos) => ({
                            _id: pos._id,
                            name: pos.name,
                            code: pos.code,
                        })),
                    };
                }
                return null;
            } catch (e) {
                console.error("Error formatting teacher:", e);
                return null;
            }
        }).filter((teacher) => teacher != null);

        res.status(200).json({
            success: true,
            data: formattedTeachers,
            pagination: pagination,
        });
    } catch (error) {
        console.error("Error in getTeachers:", error);
        res.status(500).json({
            success: false,
            message: 'Lỗi server.',
        });
    }
};


const createTeacher = async (req, res) => {
    try {
        const { teacherPositionsId, degrees, startDate, endDate, name, email, phoneNumber, address, identity, dob, role } = req.body;

        if (!name) {
            return res.status(400).json({
                success: false,
                message: 'Tên người dùng là bắt buộc.',
            });
        }

        if (!email) {
            return res.status(400).json({
                success: false,
                message: 'Email là bắt buộc.',
            });
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Định dạng email không hợp lệ.',
            });
        }

        if (!role) {
            return res.status(400).json({
                success: false,
                message: 'Vai trò người dùng là bắt buộc.',
            });
        }

        if (role.toUpperCase() !== 'TEACHER' && role.toUpperCase() !== 'ADMIN') {
            return res.status(400).json({
                success: false,
                message: 'Vai trò người dùng không hợp lệ.',
            });
        }

        if (phoneNumber && isNaN(phoneNumber)) {
            return res.status(400).json({
                success: false,
                message: 'Số điện thoại không hợp lệlệ.',
            });
        }


        const existingUserEmail = await userRepository.getUserByEmail(email);
        if (existingUserEmail) {
            return res.status(409).json({
                success: false,
                message: 'Email này đã được đăng ký bởi một người dùng khác.',
            });
        }


        const existingTeacherEmail = await teacherRepository.getTeacherByEmail(email);
        if (existingTeacherEmail) {
            return res.status(400).json({
                success: false,
                message: 'Email này đã được sử dụng cho một giáo viên khác.',
            });
        }


        const newUser = await userRepository.createUser({
            name,
            email,
            phoneNumber,
            address,
            identity,
            dob,
            role: role.toUpperCase(),
        });

        if (!newUser) {
            return res.status(500).json({
                success: false,
                message: 'Không thể tạo người dùng mới.',
            });
        }

        let code;
        let codeExists = true;
        while (codeExists) {
            code = generateRandomCode();
            const existingTeacherCode = await teacherRepository.getTeacherByCode(code);
            if (!existingTeacherCode) {
                codeExists = false;
            }
        }

    

        if (!newTeacher) {
            await userRepository.deleteUser(newUser._id);
            return res.status(500).json({
                success: false,
                message: 'Không thể tạo thông tin giáo viên. Đã hoàn tác việc tạo người dùng.',
            });
        }

        res.status(201).json({
            success: true,
            data: {
                ...newTeacher.toObject(),
                user: newUser.toObject()
            },
            message: 'Tạo thông tin giáo viên và người dùng thành công!',
        });
    } catch (error) {
        console.error("Error in createTeacher:", error);
        if (error.name === 'ValidationError') {
            return res.status(400).json({ success: false, message: error.message });
        }
        res.status(500).json({
            success: false,
            message: 'Đã có lỗi xảy ra, vui lòng liên hệ kỹ thuật.',
        });
    }
};

export default {
    getTeachers,
    createTeacher,
};