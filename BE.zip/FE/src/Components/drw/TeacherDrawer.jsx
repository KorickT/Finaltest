import React, { useState, useEffect, useCallback } from 'react';
import {
    Drawer,
    Box,
    IconButton,
    Typography,
    TextField,
    Grid,
    Button,
    Avatar,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Tooltip,
    Alert,
} from '@mui/material';
import { Close as CloseIcon, CloudUpload as CloudUploadIcon, Add as AddIcon } from '@mui/icons-material';
import DatePicker from '@mui/lab/DatePicker';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import managementApi from '../../api/managementapi.js';

const AddTeacherDrawer = ({ open, onClose, addTeacherCallback }) => {
    const [teacherInfo, setTeacherInfo] = useState({
        profileImage: null,
        name: '',
        dob: null,
        phoneNumber: '',
        email: '',
        identity: '',
        address: '',
        positionId: '',
        role: 'TEACHER',
        degrees: [],
    });
    const [imagePreviewUrl, setImagePreviewUrl] = useState(null);
    const [availablePositions, setAvailablePositions] = useState([]);
    const [apiError, setApiError] = useState(null);
    const [apiSuccess, setApiSuccess] = useState(null);
    const fetchPositions = async () => {
        try {
            const response = await managementApi.getTeacherPositions();
            if (response.success) {
                setAvailablePositions(response.data);
                console.log(response.data)
            } else {
                console.error("Failed to fetch teacher positions:", response.message);
                setApiError(response.message || "Failed to fetch teacher positions.");
            }
        } catch (error) {
            console.error("Error fetching teacher positions:", error);
            setApiError(error.message || "Error fetching teacher positions.");
        }
    };
    useEffect(() => {
        if (open) {
            fetchPositions();
        }
    }, [open]);

    const handleInputChange = (e) => {
        if (e.target.name === 'positionId') {
            setTeacherInfo({ ...teacherInfo, positionId: e.target.value });
        } else {
            setTeacherInfo({ ...teacherInfo, [e.target.name]: e.target.value });
        }
    };

    const handleDateChange = (name, date) => {
        setTeacherInfo({ ...teacherInfo, [name]: date });
    };

    const handleImageUpload = (event) => {
        const file = event.target.files[0];
        if (file) {
            setTeacherInfo({ ...teacherInfo, profileImage: file });
            setImagePreviewUrl(URL.createObjectURL(file));
        }
    };

    const handleSave = async () => {
        setApiError(null);
        setApiSuccess(null);

        const teacherDataForApi = {
            teacherPositionsId: teacherInfo.positionId,
            degrees: teacherInfo.degrees,
            name: teacherInfo.name,
            email: teacherInfo.email,
            phoneNumber: teacherInfo.phoneNumber,
            address: teacherInfo.address,
            identity: teacherInfo.identity,
            dob: teacherInfo.dob,
            role: teacherInfo.role,
        };

        try {
            const response = await managementApi.createTeacher(teacherDataForApi);
            if (response.success) {
                setApiSuccess(response.message);
                if (addTeacherCallback) {
                    addTeacherCallback(response.data);
                }
                setTimeout(() => {
                    onClose();
                    setTeacherInfo({
                        profileImage: null,
                        name: '',
                        dob: null,
                        phoneNumber: '',
                        email: '',
                        identity: '',
                        address: '',
                        positionId: '',
                        role: 'TEACHER',
                        degrees: [],
                    });
                    setImagePreviewUrl(null);
                    setApiSuccess(null);
                }, 1500);
            } else {
                setApiError(response.message || "Failed to create teacher.");
            }
        } catch (error) {
            console.error("Error creating teacher:", error);
            setApiError(error.response?.data?.message || error.message || "Error creating teacher.");
        }
    };

    const handleAddDegree = () => {
        setTeacherInfo({
            ...teacherInfo,
            degrees: [...teacherInfo.degrees, { type: '', school: '', major: '', isGraduated: false, year: null }],
        });
    };

    const handleDegreeChange = (index, field, value) => {
        const newDegrees = [...teacherInfo.degrees];
        if (field === 'isGraduated') {
            newDegrees[index][field] = value === 'true' ? true : false;
            if (value === 'false') {
                newDegrees[index]['year'] = null;
            }
        } else if (field === 'year') {
            newDegrees[index][field] = value ? parseInt(value, 10) : null;
        }
        else {
            newDegrees[index][field] = value;
        }
        setTeacherInfo({ ...teacherInfo, degrees: newDegrees });
    };

    const handleRemoveDegree = (index) => {
        const newDegrees = teacherInfo.degrees.filter((_, i) => i !== index);
        setTeacherInfo({ ...teacherInfo, degrees: newDegrees });
    };


    return (
        <Drawer
            anchor="right"
            open={open}
            onClose={onClose}
            PaperProps={{ sx: { width: '50vw' } }}
        >
            <Box sx={{ p: 3 }}>
                <IconButton onClick={onClose} sx={{ position: 'absolute', top: 8, right: 8 }}>
                    <CloseIcon />
                </IconButton>
                <Typography variant="h6" mb={2}>
                    Tạo thông tin giáo viên
                </Typography>

                {apiError && (
                    <Alert severity="error" sx={{ mb: 2 }}>{apiError}</Alert>
                )}
                {apiSuccess && (
                    <Alert severity="success" sx={{ mb: 2 }}>{apiSuccess}</Alert>
                )}

                <Grid container spacing={2}>
                    <Grid item xs={12} md={4} display="flex" flexDirection="column" alignItems="center">
                        <Avatar
                            src={imagePreviewUrl}
                            sx={{ width: 100, height: 100, mb: 1 }}
                            alt="Profile Image"
                        />
                        <Tooltip title="Chọn ảnh">
                            <IconButton component="label">
                                <CloudUploadIcon />
                                <input
                                    type="file"
                                    hidden
                                    accept="image/*"
                                    onChange={handleImageUpload}
                                />
                            </IconButton>
                        </Tooltip>
                        <Typography variant="caption" display="block" >Chọn ảnh</Typography>
                    </Grid>

                    <Grid item xs={12} md={8}>
                        <Typography variant="subtitle1" mb={1}>Thông tin cá nhân</Typography>
                        <TextField
                            fullWidth
                            label="Họ và tên"
                            name="name"
                            variant="outlined"
                            size="small"
                            margin="dense"
                            required
                            placeholder="VD: Nguyễn Văn A"
                            value={teacherInfo.name}
                            onChange={handleInputChange}
                        />
                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                            <DatePicker
                                label="Ngày sinh"
                                value={teacherInfo.dob}
                                onChange={(newValue) => handleDateChange('dob', newValue)}
                                renderInput={(params) => <TextField {...params} fullWidth variant="outlined" size="small" margin="dense" required />}
                            />
                        </LocalizationProvider>
                        <TextField
                            fullWidth
                            label="Số điện thoại"
                            name="phoneNumber"
                            variant="outlined"
                            size="small"
                            margin="dense"
                            required
                            placeholder="Nhập số điện thoại"
                            value={teacherInfo.phoneNumber}
                            onChange={handleInputChange}
                        />
                        <TextField
                            fullWidth
                            label="Email"
                            name="email"
                            variant="outlined"
                            size="small"
                            margin="dense"
                            required
                            placeholder="example@school.edu.vn"
                            value={teacherInfo.email}
                            onChange={handleInputChange}
                        />
                        <TextField
                            fullWidth
                            label="Số CCCD"
                            name="identity"
                            variant="outlined"
                            size="small"
                            margin="dense"
                            required
                            placeholder="Nhập số CCCD"
                            value={teacherInfo.identity}
                            onChange={handleInputChange}
                        />
                        <TextField
                            fullWidth
                            label="Địa chỉ"
                            name="address"
                            variant="outlined"
                            size="small"
                            margin="dense"
                            required
                            placeholder="Địa chỉ thường trú"
                            value={teacherInfo.address}
                            onChange={handleInputChange}
                        />
                    </Grid>
                </Grid>

                <Typography variant="subtitle1" mt={2} mb={1}>Thông tin công tác</Typography>
                <FormControl fullWidth margin="dense" size="small" required>
                    <InputLabel id="vi-tri-cong-tac-label">Vị trí công tác</InputLabel>
                    <Select
                        labelId="vi-tri-cong-tac-label"
                        id="positionId"
                        name="positionId"
                        value={teacherInfo.positionId}
                        label="Vị trí công tác"
                        onChange={handleInputChange}
                    >
                        {availablePositions && availablePositions.map((pos) => (
                            <MenuItem key={pos._id} value={pos._id}>{pos.name}</MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <Typography variant="subtitle1" mt={2} mb={1}>Học vị</Typography>
                <TableContainer component={Paper}>
                    <Table size="small">
                        <TableHead>
                            <TableRow>
                                <TableCell>Bậc</TableCell>
                                <TableCell>Trường</TableCell>
                                <TableCell>Chuyên ngành</TableCell>
                                <TableCell>Trạng thái</TableCell>
                                <TableCell>Tốt nghiệp</TableCell>
                                <TableCell align="right">
                                    <Tooltip title="Thêm học vị">
                                        <IconButton onClick={handleAddDegree}>
                                            <AddIcon />
                                        </IconButton>
                                    </Tooltip>
                                </TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {teacherInfo.degrees.map((degreeItem, index) => (
                                <TableRow key={index}>
                                    <TableCell>
                                        <TextField
                                            fullWidth
                                            size="small"
                                            value={degreeItem.type}
                                            onChange={(e) => handleDegreeChange(index, 'type', e.target.value)}
                                        />
                                    </TableCell>
                                    <TableCell>
                                        <TextField
                                            fullWidth
                                            size="small"
                                            value={degreeItem.school}
                                            onChange={(e) => handleDegreeChange(index, 'school', e.target.value)}
                                        />
                                    </TableCell>
                                    <TableCell>
                                        <TextField
                                            fullWidth
                                            size="small"
                                            value={degreeItem.major}
                                            onChange={(e) => handleDegreeChange(index, 'major', e.target.value)}
                                        />
                                    </TableCell>
                                    <TableCell>
                                        <FormControl fullWidth size="small">
                                            <Select
                                                value={String(degreeItem.isGraduated)}
                                                onChange={(e) => handleDegreeChange(index, 'isGraduated', e.target.value)}
                                            >
                                                <MenuItem value={String(true)}>Đã tốt nghiệp</MenuItem>
                                                <MenuItem value={String(false)}>Chưa tốt nghiệp</MenuItem>
                                            </Select>
                                        </FormControl>
                                    </TableCell>
                                    <TableCell>
                                        {degreeItem.isGraduated === true && (
                                            <TextField
                                                fullWidth
                                                size="small"
                                                type="number"
                                                label="Năm tốt nghiệp"
                                                value={degreeItem.year || ''}
                                                onChange={(e) => handleDegreeChange(index, 'year', e.target.value)}
                                                required={degreeItem.isGraduated === true}
                                            />
                                        )}
                                    </TableCell>
                                    <TableCell align="right">
                                        <Tooltip title="Xóa học vị">
                                            <IconButton onClick={() => handleRemoveDegree(index)}>
                                                <CloseIcon />
                                            </IconButton>
                                        </Tooltip>
                                    </TableCell>
                                </TableRow>
                            ))}
                            {teacherInfo.degrees.length === 0 && (
                                <TableRow>
                                    <TableCell colSpan={6} align="center" style={{ fontStyle: 'italic', color: 'grey' }}>
                                        Trống
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>


                <Box mt={3} display="flex" justifyContent="flex-end">
                    <Button variant="contained" color="primary" onClick={handleSave}>
                        Lưu
                    </Button>
                </Box>
            </Box>
        </Drawer>
    );
};

export default AddTeacherDrawer;