import React from 'react';
import Table from '@mui/joy/Table';
import './Table.css'
import Sheet from '@mui/joy/Sheet';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';

function ManagementTable({
    head = [],
    data = [],
    truthTable = {},
    customDataDisplay = {},
    HeadStyling = {},
    customColSize = {}
}) {
    return (
        <Sheet sx={{ height: "50vh", overflow: 'auto' }}>
            {data.length === 0 ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', flexDirection: 'column' }}>
                    <CircularProgress />
                    <Box mt={2} color="text.secondary">Loading Data...</Box>
                </Box>
            ) : (
                <Table aria-label="basic table" sx={{ maxHeight: "500px", overflow: "scroll" }} stickyHeader>
                    <thead>
                        <tr>
                            {head.map((h) => (
                                <th key={h} style={{
                                    ...HeadStyling[h],
                                    ...(customColSize && customColSize[h] ? { width: customColSize[h] } : {})
                                }}>
                                    {h}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map((e, rowIndex) => (
                                <tr key={rowIndex}>
                                    {
                                        head.map((h) => (
                                            <td key={h}>
                                                {
                                                    customDataDisplay[h]
                                                        ? customDataDisplay[h](e[truthTable[h]], e)
                                                        : (typeof e[truthTable[h]] === 'string' || typeof e[truthTable[h]] === 'number'
                                                            ? e[truthTable[h]]
                                                            : e[truthTable[h]] || "N/A"
                                                        )
                                                }
                                            </td>
                                        ))
                                    }
                                </tr>
                            ))
                        }
                    </tbody>
                </Table>
            )}
        </Sheet>

    );
}
export default ManagementTable;