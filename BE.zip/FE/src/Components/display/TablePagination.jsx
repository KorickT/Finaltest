import React from 'react';
import { Box, Button, Select, MenuItem, Typography, IconButton } from '@mui/material';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

const CustomNavBar = ({
  totalRecords,
  currentPage,
  recordsPerPage,
  recordsPerPageOptions,
  setRecordPerPage,
  changePage,
}) => {

  let totalPages = Math.ceil(totalRecords / recordsPerPage)

  const handleRecordPerPageChange = (event) => {
    setRecordPerPage(event.target.value);
  };

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      changePage(page);
    } else {
      console.log("Warning: No page to change.")
    }
  };

  return (
    <Box display="flex" alignItems="center" justifyContent="right" width="100%" marginTop="50px">
      <Typography variant="body1" sx={{ mr: 2 }}>
        Tổng: {totalRecords}
      </Typography>

      <IconButton
        onClick={() => handlePageChange(currentPage - 1)}
        disabled={currentPage === 1}
        size="small"
      >
        <ArrowBackIosNewIcon fontSize="inherit" />
      </IconButton>

      {[...Array(Math.min(3, totalPages)).keys()].map((pageIndex) => {
        const pageNumber = pageIndex + 1;
        return (
          <Button
            key={pageNumber}
            onClick={() => handlePageChange(pageNumber)}
            variant={currentPage === pageNumber ? 'contained' : 'outlined'}
            color={currentPage === pageNumber ? 'primary' : 'default'}
            size="small"
            sx={{ ml: 0.5, mr: 0.5 }}
          >
            {pageNumber}
          </Button>
        );
      })}
      {totalPages > 3 && currentPage > 3 && <Typography sx={{ ml: 0.5, mr: 0.5 }}>...</Typography>}
      {totalPages > 3 && currentPage <= 3 && totalPages > 3 && <Button disabled size="small" sx={{ ml: 0.5, mr: 0.5 }} variant='text'>...</Button>}
      {totalPages > 3 && totalPages > 3 && currentPage > 3 && totalPages > 3 && <Button
        key={totalPages}
        onClick={() => handlePageChange(totalPages)}
        variant={currentPage === totalPages ? 'contained' : 'outlined'}
        color={currentPage === totalPages ? 'primary' : 'default'}
        size="small"
        sx={{ ml: 0.5, mr: 0.5 }}
      >
        {totalPages}
      </Button>}


      <IconButton
        onClick={() => handlePageChange(currentPage + 1)}
        disabled={currentPage === totalPages || totalPages === 0}
        size="small"
        sx={{ ml: 0.5 }}
      >
        <ArrowForwardIosIcon fontSize="inherit" />
      </IconButton>

      <Box sx={{ ml: 2 }}>
        <Select
          value={recordsPerPage}
          onChange={handleRecordPerPageChange}
          variant="outlined"
          size="small"
        >
          {recordsPerPageOptions.map((option) => (
            <MenuItem key={option} value={option}>
              {option} / trang
            </MenuItem>
          ))}
        </Select>
      </Box>
    </Box>
  );
};

export default CustomNavBar;