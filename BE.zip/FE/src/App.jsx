import { BrowserRouter, Routes, Route } from 'react-router-dom';
import PositionDetail from './pages/positionDetail';
import Dashboard from './pages/dashboard';
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/management/positions" element={<PositionDetail />} />
        <Route path="/management/teachers" element={<Dashboard />} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;